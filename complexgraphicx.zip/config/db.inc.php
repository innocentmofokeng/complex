<?php   

$db_hostname = 'localhost';
$db_database = 'complexgraphicx';
$db_username = 'root';
$db_password = '';



?>